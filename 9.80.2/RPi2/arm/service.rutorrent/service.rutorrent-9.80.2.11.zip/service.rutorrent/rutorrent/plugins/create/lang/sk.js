﻿/*
 * PLUGIN CREATE
 *
 * Slovak language file.
 *
 * Author: 
 */

 theUILang.mnu_create			= "Create Torrent...";
 theUILang.CreateNewTorrent		= "Create New Torrent";
 theUILang.SelectSource			= "Select Source";
 theUILang.TorrentProperties		= "Torrent Properties";
 theUILang.PieceSize			= "Piece size";
 theUILang.Other			= "Other";
 theUILang.StartSeeding			= "Start seeding";
 theUILang.PrivateTorrent		= "Private torrent";
 theUILang.torrentCreate		= "Create...";
 theUILang.BadTorrentData		= "You must fill all required fields!";
 theUILang.createExternalNotFound	= "Create plugin: Plugin will not work. Webserver user can't access external program";
 theUILang.incorrectDirectory		= "Incorrect directory";
 theUILang.cantExecExternal		= "Can't execute external program";
 theUILang.createConsole		= "Console";
 theUILang.createErrors			= "Errors";
 theUILang.torrentSave			= "Save";
 theUILang.torrentKill			= "Stop";
 theUILang.torrentKilled		= "Process was stopped.";
 theUILang.recentTrackers		= "Recent trackers";
 theUILang.source			= "Source";

thePlugins.get("create").langLoaded();