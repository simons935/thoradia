﻿/*
 * PLUGIN COOKIES
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.cookiesDesc		= "Cookies (Format: vert|cookie1;cookie2...)";
 theUILang.cookiesName		= "Cookies";

thePlugins.get("cookies").langLoaded();