﻿/*
 * PLUGIN COOKIES
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.cookiesDesc		= "Ciasteczka (Format: adres|ciasteczko1;ciasteczko2...)";
 theUILang.cookiesName		= "Ciasteczka";

thePlugins.get("cookies").langLoaded();