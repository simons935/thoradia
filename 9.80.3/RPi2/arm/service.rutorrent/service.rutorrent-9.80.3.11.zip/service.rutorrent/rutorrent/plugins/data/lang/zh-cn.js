﻿/*
 * PLUGIN DATA
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.getData		= "获取数据";
 theUILang.cantAccessData	= "网页服务器执行用户不能访问这个 torrent 的数据.";

thePlugins.get("data").langLoaded();
