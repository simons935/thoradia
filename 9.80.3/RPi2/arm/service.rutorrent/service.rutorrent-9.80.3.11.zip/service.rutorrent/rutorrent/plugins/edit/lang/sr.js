﻿/*
 * PLUGIN EDIT
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com)
 */

 theUILang.EditTrackers			= "Уреди торент...";
 theUILang.EditTorrentProperties	= "Својства торента";
 theUILang.errorAddTorrent		= "Грешка код додавања датотеке торенту";
 theUILang.errorWriteTorrent		= "Грешка код писања торент-датотеке";
 theUILang.errorReadTorrent		= "Грешка код читања торент-датотеке";
 theUILang.cantFindTorrent		= "Изворна торент-датотека за овај низтовар није нађена."

thePlugins.get("edit").langLoaded();