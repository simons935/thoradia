﻿/*
 * PLUGIN CHUNKS
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.Chunks		= "조각";
 theUILang.cAvail		= "가용성";
 theUILang.cDownloaded		= "다운로드됨";
 theUILang.cMode		= "보기";
 theUILang.chunksCount		= "조각 개수";
 theUILang.chunkSize		= "조각 크기";
 theUILang.cLegend		= "범례";
 theUILang.cLegendVal		= [ "셀당 조각 4개", "셀당 조각 1개" ];

thePlugins.get("chunks").langLoaded();
