﻿/*
 * PLUGIN DISKSPACE
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.diskNotification	= "Attention! Votre espace disque est plein. rTorrent peut ne pas fonctionner normalement, et aucune données ne sera téléchargée jusqu'à ce que vous libériez de l'espace.";

thePlugins.get("diskspace").langLoaded();