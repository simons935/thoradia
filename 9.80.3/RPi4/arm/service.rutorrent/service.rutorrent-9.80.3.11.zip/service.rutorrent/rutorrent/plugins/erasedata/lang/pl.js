﻿/*
 * PLUGIN ERASEDATA
 *
 * Polish language file.
 *
 * Author: dolohow, mmalisz
 */

 theUILang.Rem_torrents_content_prompt		= "Czy na pewno chcesz usunąć wybrane torrenty? UWAGA: Zostanie usunięta zawartość torrenta.";
 theUILang.Delete_data_with_path		= "Skasuj cały katalog";
 theUILang.Rem_torrents_with_path_prompt	= "Czy na pewno chcesz usunąć wybrane torrenty? UWAGA: Zostanie usunięta cała zawartość katalogu torrenta.";

thePlugins.get("erasedata").langLoaded();
