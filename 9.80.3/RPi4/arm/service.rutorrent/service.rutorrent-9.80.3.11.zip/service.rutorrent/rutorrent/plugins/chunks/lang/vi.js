﻿/*
 * PLUGIN CHUNKS
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.Chunks		= "Các khối";
 theUILang.cAvail		= "Khả dụng";
 theUILang.cDownloaded		= "Đã tải";
 theUILang.cMode		= "Chế độ";
 theUILang.chunksCount		= "Số khối";
 theUILang.chunkSize		= "Kích thước khối";
 theUILang.cLegend		= "Chú thích";
 theUILang.cLegendVal		= [ "Mỗi ô 4 khối", "Mỗi ô 1 khối" ];

thePlugins.get("chunks").langLoaded();